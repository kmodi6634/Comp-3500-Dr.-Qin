#include <stdio.h>
#include <math.h>

int main() {
    double numbers[10] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0};
    double sum = 0.0;
    
    for (int i = 0; i < 10; i++) {
        sum += sqrt(numbers[i]);
    }
    
    double average = sum / 10.0;
    printf("Average of square roots: %f\n", average);
    return 0;
}

